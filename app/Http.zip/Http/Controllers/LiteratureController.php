<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Literature;
use App\Models\Category;
use App\Models\LiteratureCategory;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Storage;
use Image;

class LiteratureController extends Controller
{
    public function list()
    {
        $currentUser = Auth::user();
        $data = Literature::where('user_id', '=', $currentUser->id)->orderBy('order_number', 'ASC')->get();
        return view('admin.literature.list', ['lists' => $data]);
    }

    public function add()
    {
        $data1 = LiteratureCategory::all();
        return view('admin.literature.add', ['lists1' => $data1]);
    }

    public function store(Request $request)
    {
        ini_set('upload_max_filesize', '200M');
        ini_set('post_max_size', '200M');

        $rules = $request->validate([
            'title' => 'required',
            'slug' => 'required',
            // 'literature_category_id' => 'required',
            'body' => 'required|string',
            'featuredimages.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048' // Validate each image file
        ]);
        $data = new Literature();
        if ($request->hasFile('featuredimages')) {
            // $image = $request->file('featuredimages');
            // $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
            

            // $s3 = Storage::disk('s3');
            // $originalImageUrl =  env('AWS_URL') . env('AWS_FOLDER_NAME') . $imageName;
           
            // $midImage = Image::make($originalImageUrl)->resize(700, null, function ($constraint) {
            //     $constraint->aspectRatio();
            // });
            // // Load and resize the watermark image to match the dimensions of the uploaded image
            // $watermark = Image::make(public_path('featured-image/watermark-logo.png'));
            // $watermark->fit($midImage->width(), $midImage->height());
            // $midImage->insert($watermark, 'center');
            // $watermark_filename = time().rand().'-watermark.jpg';
            // Storage::disk('s3')->put(env('AWS_FOLDER_NAME'). $watermark_filename, $midImage->encode());        
            // // Store the watermarked image path            
            // $data->watermarkimage = $watermark_filename;
            // $data->featuredimage = $imageName;

            $imagePaths = [];
            if ($request->hasFile('featuredimages')) {
                $counter = 0; 
                foreach ($request->file('featuredimages') as $key => $image) {
                    if ($counter < 2) { 
                    $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
                    $imagePaths[] = $imageName; 
                    $counter++;
                }
                }
            }
            $data->featuredimage = $imagePaths;
         }
       

        $data->user_id = Auth::id();
        $data->title = $rules['title'];
        // $data->literature_category_id = $rules['literature_category_id'];
        $data->slug = $rules['slug'];
        $data->body = $rules['body'];
        $data->order_number = $request->order_number;
        $data->status = $request->status ? $request->status : 0;
        $data->save();
        $data->literature_categories()->sync($request->categories);
        return redirect()->route('admin.literature_list');
    }

    public function edit($id)
    {
        $data = Literature::with('literature_categories')->find($id);
        $data1 = LiteratureCategory::all();
        return view('admin.literature.edit', ['edits' => $data, 'categories' => $data1]);
    }

    public function update(Request $request)
    {
        ini_set('upload_max_filesize', '200M');
        ini_set('post_max_size', '200M');
        $rules = $request->validate([
            'title' => 'required',
            'slug' => 'required',
            'body' => 'required',
            // 'literature_category_id' => 'required',
            'featuredimages' => 'nullable'

        ]);
        
        if ($request->hasFile('featuredimages')) {

            // $image = $request->file('featuredimages');
            $data = Literature::find($request->id);

            // $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));

            // $s3 = Storage::disk('s3');
            // $originalImageUrl =  env('AWS_URL') . env('AWS_FOLDER_NAME') . $imageName;
           
            // $midImage = Image::make($originalImageUrl)->resize(700, null, function ($constraint) {
            //     $constraint->aspectRatio();
            // });
            // // Load and resize the watermark image to match the dimensions of the uploaded image
            // $watermark = Image::make(public_path('featured-image/watermark-logo.png'));
            // $watermark->fit($midImage->width(), $midImage->height());
            // $midImage->insert($watermark, 'center');
            // $watermark_filename = time().rand().'-watermark.jpg';
            // Storage::disk('s3')->put(env('AWS_FOLDER_NAME'). $watermark_filename, $midImage->encode());        
        

            $imagePaths = [];
                $counter = 0; 
                foreach ($request->file('featuredimages') as $key => $image) {
                    if ($counter < 2) { 
                    $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
                    $imagePaths[] = $imageName; 
                    $counter++;
                }
                }

                $prevImages = unserialize($data->getRawOriginal('featuredimage'));
                $newFeatureImages = array_merge($prevImages,$imagePaths);
    
                $data->featuredimage = $newFeatureImages;

                // $data->featuredimage = $imagePaths;

            // delete old images from folder and db
            // if (!empty($data->featuredimage) && $data->featuredimage != "") {
            //     $result =  deleteImageFromS3($data->featuredimage['name'], env('AWS_FOLDER_NAME') );
            // }

             $data->title = $rules['title'];
             $data->slug = $rules['slug'];
             $data->body = $rules['body'];
             $data->order_number = $request->order_number;
             $data->status = $request->status ? $request->status : 0;
            //  $data->featuredimage = $imageName;
            //  $data->watermarkimage = $watermark_filename;
             
          
             $data->save();
             $data->literature_categories()->sync($request->categories);
         }else {
            $data = Literature::find($request->id);
            $data->user_id = Auth::id();
            $data->title = $rules['title'];
            $data->slug = $rules['slug'];
            $data->body = $rules['body'];
            $data->order_number = $request->order_number;
            $data->status = $request->status ?  $request->status : 0;
            $data->save();
            $data->literature_categories()->sync($request->categories);
        }

        return redirect()->route('admin.literature_list');
    }


    public function destroy($id)
    {
        $data = Literature::find($id);
        $data->delete();
        return redirect()->route('admin.literature_list');
    }

    public function check_lit_duplicate_order($val =""){
        $data = Literature::where('order_number',$val)->count();   
        return $data;
    }


    
    public function delete_literature_image($id,$name){
        $data = Literature::find($id);
        $images = unserialize($data->getRawOriginal('featuredimage'));
        $indexToDelete = null;
        foreach ($images as $index => $image) {
            if ($image === $name) {
                deleteImageFromS3($name, env('AWS_FOLDER_NAME') );
                $indexToDelete = $index;
                break;
            }
        }
        // If a matching image is found, unset it
        if ($indexToDelete !== null) {
            unset($images[$indexToDelete]);
        }
        $data->featuredimage = $images;
        $data->save();
        return 1;
    }


    public function orderUpdate(Request $request)
    {
        $sortedIDs = $request->input('sorted_data');
        foreach ($sortedIDs as $index => $id) {
            Literature::where('id', $id)->update(['order_number' => $index + 1]);
        }
        return response()->json(['success' => true]);
    }


}
