const chatSchema = require("../../models/chat/chat");
const { verifyToken } = require("../../utils/utils");
const userMaster = require("../../models/userMaster/userMasterSchema");
const chatRoomSchema = require("../../models/chat/chatRoom");
const cwListSchema = require("../../models/cw-list/cw-list");
const astroCwListSchema = require("../../models/astro-cw-list/astro-cw-list");
const userWalletSchema = require("../../models/user-wallet/user-wallet");
const astrologerWalletSchema = require("../../models/astrologer-wallet/astrologer-wallet");
const chatCallSchema = require("../../models/chat-call-transaction/chat-call-transaction");
const { USER_TYPE, CWC_LIST } = require("../../json/enums.json");
const thirdPartyApi = require("../../json/thirdPartyApi.json");
const { v4: uuidv4 } = require("uuid");
const { decode } = require("jsonwebtoken");
const utils = require("../../utils/utils");
const axios = require("axios");

module.exports = (io) => {
  io.use(async (socket, next) => {
    // authentication
    try {
      const token = socket.handshake.headers["x-auth-token"];
      if (!token) return next(new Error("Authentication error"));

      const user = await verifyToken(token);
      if (!user) return next(new Error("Authentication error"));

      socket.user = user;
      next();
    } catch (error) {
      console.log("error: ", error);

      switch (error.message) {
        case "jwt expired" || "jwt malformed":
          next(new Error(message.tokenExpired));
          break;

        default:
          next(new Error(error.message));
          break;
      }
    }
  });

  io.on("connection", async (socket) => {
    try {
      console.log("socket connected");
      // Find astrologer and user
      let aid,
        userId,
        roomId,
        chatHistory,
        findUserWallet,
        chatRoom,
        userMaxMin,
        roomCount;

      if (socket.user.role == USER_TYPE.ASTROLOGER) aid = socket.user._id;
      else userId = socket.user._id;

      if (aid) {
        socket.on("get-cw-list", async () => {
          const findcwList = await cwListSchema
            .findOne({
              aid: aid,
            })
            .populate("aid")
            .populate("users.userId");

          if (!findcwList) return socket.emit("error", "No data found");
          socket.emit("cw-list", {
            success: true,
            data: findcwList,
          });
        });
      }

      
      if (userId) {
        socket.on("get-cw-astro-list", async () => {
            // const cwAstroList = await cwListSchema.find({ "users.userId": userId })
            // .populate('aid');
            const cwAstroList = await astroCwListSchema
            .find({ userId: userId })
            .populate({
              path: "userId",
              select: "userName emailId profileImage isVerified socketId _id role",
            })
            .populate({
              path: "astro.aid",
              select: "userName profileImage isVerified socketId _id role emailId",
            });

          if (!cwAstroList) return socket.emit("error", "No data found");
          socket.emit("cw-astro-list", {
            success: true,
            data: cwAstroList,
          });
        });
      }


      socket.on("astro-inform", async (data) => {
        const astro = await userMaster.findOne({ _id: data.aid });

        const findcwList = await cwListSchema
          .findOne({
            aid: data.aid,
          })
          .populate("aid")
          .populate("users.userId");

        socket.to(astro.socketId).emit("cw-list", {
          success: true,
          data: findcwList,
        });
      });

      let findUserForSocket = await userMaster.findOneAndUpdate(
        {
          _id: socket.user._id,
        },
        { $set: { socketId: socket.id } },
        { new: true }
      );
      if (!findUserForSocket) return socket.emit("error", "User not found");

      socket.on("c-user-req", async (data) => {
        console.log('data',data);
        let reqToUser = await userMaster.findOne({
          _id: data.userId,
        });

        console.log('reqToUser',reqToUser);
        
        let astroData = await userMaster.findOne({
          _id:aid,
        });

        let resData = {
          aid: aid,
          name:astroData.userName,
          image:astroData.profileImage,
          message: "request received from astrologer",
        };
        console.log('resData',resData);


        const astrocwlistData = await astroCwListSchema.findOneAndUpdate(
          {
            userId: data.userId,
            "astro.aid": aid,
          },
          {
            $set: {
              "astro.$.status": 'running',
            },
          },
          { new: true } 
        );
        // chatCallSchema.deleteMany({}, (err) => {
        //   if (err) {
        //       console.error('Error emptying collection:', err);
        //   } else {
        //       console.log('Collection emptied successfully');
        //   }
      // });
        console.log('astrocwlistData',astrocwlistData);
        await chatCallSchema.findOneAndUpdate(
          {"userId":data.userId, "astroId":aid, status:"waiting"},
          {
            $set:{'status':'running'}
          }
          );

          if(reqToUser){
            socket.to(reqToUser.socketId).emit("user-req", resData);
          }
      });

      socket.on("accept-req", async (data) => {
        if (data.status == true) {
          let reqToUser = await userMaster.findOne({
            _id: data.aid,
          });
          const findcwListUpdate = await cwListSchema.update(
            {
              aid: data.aid,
              "users.userId": userId,
            },
            {
              $set: {
                "users.$.status": CWC_LIST.RUNNING,
              },
            }
          );
          if (!findcwListUpdate) return socket.emit("error", "No data found");

          let resData = {
            aid: data.aid,
            message: "request accepted by user join room",
          };
          if(reqToUser){
            socket.to(reqToUser.socketId).emit("user-res", resData);
          }
        } else {
          const findcwListUpdate = await cwListSchema.update(
            {
              aid: data.aid,
              "users.userId": userId,
            },
            {
              $pull: {
                users: {
                  userId: userId,
                },
              },
            }
          );
          if (!findcwListUpdate) return socket.emit("error", "No data found");

          socket.emit("user-res", "user removed in cw list successfully");
        }
      });

      // join chat room
      socket.on("join-room", async (data) => {
        console.log(' join-room id', data.id);
        const findUser = await userMaster.findOne({
          _id: data.id,
        });
        console.log(' join-room findUser',findUser);
        console.log(' join-room id', data.id);

        if (!findUser) return socket.emit("error-data", "User not found");
        if (socket.user.role == findUser.role)
          return socket.emit("error-role", "You can't chat with same role");
        if (findUser.role == USER_TYPE.ASTROLOGER) aid = findUser._id;
        else userId = findUser._id;

        chatRoom = await chatRoomSchema.findOne({
          userId: userId,
          aid: aid,
        });

        if (!chatRoom) {
          roomId = uuidv4();
          chatRoom = await chatRoomSchema.create({
            userId: userId,
            aid: aid,
            roomId: roomId,
          });
        } else {
          roomId = chatRoom.roomId;
          chatHistory = await chatSchema
            .find({ roomId: roomId })
            .sort({ createdAt: -1 });
        }

        await chatRoomSchema.findOneAndUpdate(
          {
            userId: userId,
            aid: aid,
          },
          { chatStartTime: new Date().toISOString() }
        );

        findUserWallet = await userWalletSchema.findOne({
          userId,
        });

        if (!findUserWallet) {
          const userWallet = new userWalletSchema({
            userId,
          });
          await userWallet.save();
        }
        console.log('findUserWallet.freeCredit');
        if (findUserWallet.freeCredit == false && findUserWallet.amount == 0) {
          return socket.emit("error-wallet", "Please recharge your wallet");
        }

        userMaxMin = await utils.findUserMin(findUserWallet, aid);
        console.log('userMaxMin',userMaxMin);
        if (userMaxMin < 300 && socket.user.role == USER_TYPE.USER) {
          return socket.emit("error-wallet", "Please recharge your wallet");
        }
        socket.join(roomId);
        socket.emit("chatHistory", {
          success: true,
          message: "Chat history",
          data: chatHistory,
        });
          console.log('roomId',roomId);
        if (roomId) {
          console.log('success true');
          roomCount = io.sockets.adapter.rooms.get(roomId).size;
          socket.emit("join-success", {
            success: true,
            maxMin: userMaxMin,
            message: "Join room successfully",
          });
        } else {
          console.log('success else');
          socket.emit("join-success", {
            success: false,
            message: "Room id is required",
          });
        }
      });

      // send message
      socket.on("c-new-msg", async (data) => {
        try {
          // save message to db
          const newChat = new chatSchema({
            data: data.data,
            roomId: roomId,
            senderId: socket.user._id,
            receiverId: data.id,
            dataType: data.dataType,
          });
        
      
          let saveChat = await newChat.save();
          if (!saveChat) throw new Error("Something went wrong");

          // recieve message
          socket.to(roomId).emit("server-data", {
            success: true,
            message: "New message",
            senderId: socket.user._id,
            receiverId: data.id,
            date: saveChat.date,
            data: data.data,
            dataType: data.dataType,
          });

          // send acknowledgement to sender
          socket.emit("server-data-ack", {
            success: true,
            senderId: socket.user._id,
            receiverId: data.id,
            date: saveChat.date,
            data: saveChat.data,
            dataType: data.dataType,
          });


          // const bodyData ={
          //   sender_user_id:socket.user._id,
          //   receiver_user_id: data.id,
          //   message_content:data.data,
          // }
          // axios
          // .post(thirdPartyApi.THIRD_PARTY_SAVE_MESSAGE, JSON.stringify(bodyData))
          // .then((response) => {
          //   console.log("Response: save", response.data);
          // })
          // .catch((error) => {
          //   console.error("Error:", error.message);
          // });
    


        } catch (error) {
          console.log("error : ", error);
          socket.emit("server-data", {
            success: false,
            message: "Something went wrong",
            error: error.message,
          });
        }
      });

      // emit a event to user leave a chat
      socket.on("leave-chat", async () => {
        console.log('dinesh');
        console.log('roomId',roomId);
        // socket.emit("user-leave1", {
        //   success: true,
        //   message: "User leave chat11111111",
        // });
        socket.to(roomId).emit("user-leave", {
          success: true,
          message: "User leave chat",
        });
      });

     
           // Success Response Message
            socket.on("success-response", async (data) => {
              let reqToUser = await userMaster.findOne({
                _id: data.userId,
              });
              if(reqToUser){
                let resData = {
                  aid: '12334',
                  message: "request received from astrologer",
                };
        
                socket.to(reqToUser.socketId).emit("success-msg", resData);
              }

            });

          

      // disconnect
      socket.on("disconnect", async () => {
        // // make discconection event
        // socket.to(roomId).emit("user-disconnect", {
        //   success: true,
        //   message: "User disconnected",
        // });

        //  remove user to the cw-list
        if (chatRoom) {
          // const findcwListUpdate = await cwListSchema.update(
          //   {
          //     aid: chatRoom.aid,
          //     "users.userId": chatRoom.userId,
          //   },
          //   {
          //     $pull: {
          //       users: {
          //         userId: chatRoom.userId,
          //       },
          //     },
          //   }
          // );
          // if (!findcwListUpdate)
          //   return socket.emit("error-cwList", "No data found");

          let chatRoomData = await chatRoomSchema.findOne({
            roomId: chatRoom.roomId,
            chatStartTime: { $ne: null },
          });

          if (chatRoomData) {
            let t1 = new Date(chatRoomData.chatStartTime).getTime();
            let t2 = new Date().getTime();
            let dif = t1 - t2;

            let Seconds_from_T1_to_T2 = dif / 1000;
            let Minutes_Between_Dates = Math.abs(Seconds_from_T1_to_T2) / 60;
  
            if (roomCount >= 1) {
              if (userMaxMin > 0) {
           
                let {
                  totalAmount: amount,
                  userWallet,
                  mainAmount,
                } = await utils.updateWallet(
                  findUserWallet,
                  chatRoom.aid,
                  Minutes_Between_Dates
                );
                 
                if (amount && mainAmount != 0) {
                  let PaymentData = await utils.astrologerWallet(amount);

                  const findWallet = await astrologerWalletSchema.findOne({
                    aid: chatRoom.aid,
                  });
                  if (!findWallet)
                    return socket.emit(
                      "error-Astro-Wallet",
                      "Astrologer wallet not found"
                    );

                  let astro = await utils.updateAstrologerWallet(
                    findWallet,
                    PaymentData,
                    userWallet
                  );
                }
              }
              await chatRoomSchema.findOneAndUpdate(
                {
                  roomId: chatRoom.roomId,
                },
                { chatStartTime: null },
                { new: true }
              );
            }
          }
        }
        socket.leave(roomId);
        // make discconection event
        socket.to(roomId).emit("user-disconnect", {
          success: true,
          message: "User disconnected",
        });
      });
    } catch (error) {
      console.log("error : ", error);
      socket.emit("server-data", {
        success: false,
        message: "Something went wrong",
        error: error.message,
      });
    }
  });

  io.on("error", (err) => {
    console.log("socket err", err);
  });
};
