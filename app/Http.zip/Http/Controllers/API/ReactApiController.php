<?php

namespace App\Http\Controllers\API;

use PDF;
use Stripe\Stripe;
use App\Models\Item;
use App\Models\Post;
use Aws\S3\S3Client;
use App\Models\Adorn;
use App\Models\Event;
use App\Models\Order;
use App\Models\Contact;
use App\Models\Enquire;
use App\Models\Setting;
use App\Models\Category;
use App\Models\Dimension;
use App\Models\Literature;
use App\Models\Newsletter;
use Illuminate\Http\Request;
use App\Mail\SendPurchaseMail;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;

class ReactApiController extends Controller
{

    // public function acquire_list()
    // {
    //      $perPage = 10;
    //     $result = Post::with(['categories','literatures'])->orderBy('created_at', 'DESC')->paginate($perPage);
    //     // $result = Post::with(['categories','literatures'])->orderBy('created_at', 'DESC')->get();
    //     $posts_count = $result->count();
    //     if ($result) {
    //         return response()->json([
    //             "status" => 1,
    //             "posts_count" => $posts_count,
    //             "products" => $result
    //         ]);
    //     } else {
    //         return response()->json([
    //             "status" => 0,
    //             "message" => "Operation Failed!!"
    //         ]);
    //     }
    // }

    public function acquire_list(Request $request)
    {

        $perPage = 12;
        $query = Post::with(['categories', 'literatures','items.order']);
        $categories = Category::orderBy('created_at', 'DESC')->get();
        
        
         if (!empty($request->categories)) {
        $categoryIds = explode(',', $request->categories);
        $query->whereHas('categories', function ($query) use ($categoryIds) {
            $query->whereIn('categories.id', $categoryIds);
        });
    }
        
        // Check if sorting by price is requested
        if (!empty($request->sortby)) {
            $sortOrder = $request->sortby;
            if ($sortOrder === 'low_to_high') {
                $query->orderBy('offer_price', 'ASC');
            } elseif ($sortOrder === 'high_to_low') {
                $query->orderBy('offer_price', 'DESC');
            } elseif ($sortOrder === 'latest') {
                $query->orderBy('created_at', 'DESC');
            } elseif ($sortOrder === 'popular') {
                $query->orderBy('views', 'DESC');
            }
            } 
            elseif (!empty($request->keyword)) {
            $keyword = $request->keyword;
            $query->where('title', 'LIKE', '%' . $keyword . '%');
              } 
            
        else {
            $query->orderBy('order_number', 'ASC');
        }
       
        $result = $query->paginate($perPage)->appends(request()->query())->withPath('/acquire');
        $posts_count = $result->count();
        // $sql = $query->toSql();
        // return $sql;
        if ($result) {
            return response()->json([
                "status" => 1,
                "posts_count" => $posts_count,
                "products" => $result,
                "categories" => $categories,
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }
    }

    public function get_acquire_by_id(Request $request)
    {
        $data = Post::where('slug', $request->slug)->with(['categories', 'literatures','items.order','dimension'])->first();
        $last_order = Item::with('order')->where('product_id',$data->id)->orderBy('created_at','DESC')->first();
        
        if ($request->slug) {
            $data->views = $data->views + 1;
            $data->save();
            return response()->json([
                "status" => 1,
                "products" => $data,
                'last_order' => $last_order,
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Missing Parameter",
            ]);
        }
    }

    public function art_list()
    {
        $perPage = 6;
        $result = Literature::with('literature_categories')->orderBy('order_number', 'ASC')->paginate($perPage)->withPath('/art');
        $literature_count = $result->count();
        if ($result) {
            return response()->json([
                "status" => 1,
                "literature_count" => $literature_count,
                "posts" => $result,
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }

    }

    public function aware_list()
    {
        $perPage = 6;
        $result = Event::orderBy('created_at', 'DESC')->paginate($perPage)->withPath('/aware');
        $event_count = $result->count();
        if ($result) {
            return response()->json([
                "status" => 1,
                "event_count" => $event_count,
                "events" => $result,
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }

    }


    public function aware_detail_page(Request $request)
    {
        $result = Event::where('id',$request->id)->first();
        if ($result) {
            return response()->json([
                "status" => 1,
                "event" => $result,
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }
    }


    public function addAdornForm(Request $request)
    {
        $rules = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'gender' => 'nullable',
            'country' => 'nullable',
            'tshirt' => 'nullable',
            'message' => 'nullable',
        ]);

        $data = new Adorn();
        $data->name = $rules['name'];
        $data->email = $rules['email'];
        $data->phone = $rules['phone'];
        $data->gender = $rules['gender'];
        $data->country = $rules['country'];
        $data->tshirt = $rules['tshirt'];
        $data->message = $rules['message'];
        $result = $data->save();

        if ($result) {
            return response()->json([
                "status" => 1,
                "message" => "Adorn Added Successfully!!",
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }
    }

  
    public function getProductsByIds(Request $request)
    {
      
        if($request->ids == "" && empty($request->ids)){
            return response()->json([
                "status" => 0,
                "message" => "Ids Not Found.",
            ]);
        }
        $ids = $request->ids;
        $products = Post::whereIn('id', $ids)->get();
       
        if ($products->isEmpty()) {
            return response()->json([
                "status" => 0,
                "message" => "No products found for the given IDs.",
            ]);
        }
        $totalOfferPrice = $products->sum('offer_price');
        $shippingCharge = $products->sum('shipping_charge');
        return response()->json([
            "status" => 1,
            "products" => $products,
            "total_offer_price" => $totalOfferPrice,
            'shippingCharge'=> $shippingCharge
        ]);
    }

    public function addContactForm(Request $request)
    {
        $rules = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'address' => 'nullable',
            'message' => 'nullable',
        ]);

        $existingEmail = Contact::where('email', $rules['email'])->first();

        if ($existingEmail) {
            return response()->json([
                "status" => 0,
                "message" => "Email already exists in the contacts.",
            ]);
        }
        
        $data = new Contact();
        $data->name = $rules['name'];
        $data->email = $rules['email'];
        $data->phone = $rules['phone'];
        $data->address = $rules['address'];
        $data->message = $rules['message'];
        $result = $data->save();

        if ($result) {
            return response()->json([
                "status" => 1,
                "message" => "Contact Added Successfully!!",
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }
    }

    public function addNewsletterForm(Request $request)
    {
        $rules = $request->validate([
            'email' => 'required',
        ]);

        $existingEmail = Newsletter::where('email', $rules['email'])->first();
        if ($existingEmail) {
            return response()->json([
                "status" => 0,
                "message" => "Email already exists in the newsletter list.",
            ]);
        }
        $data = new Newsletter();
        $data->email = $rules['email'];
        $result = $data->save();

        if ($result) {
            return response()->json([
                "status" => 1,
                "message" => "Subscribed Successfully!!",
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }
    }

    public function generateOrder(Request $request)
    {
        $requestData = $request->all();
        $ids = $requestData['productIds'];
        $dimensionIds = $requestData['dimensionIds'];
        $cartItems = $requestData['cart'];
        $total_offer_price = $request->total_offer_price;
        $productItems = Post::whereIn('id', $ids)->get();
        $total_amount = $productItems->sum('offer_price');
        $shipping_charge = $productItems->sum('shipping_charge');
        $uniqueId = ucwords(substr(uniqid(), -7));
        $order = Order::create([
            'unique_id' => $uniqueId,
            'first_name' => $requestData['first_name'],
            'last_name' => $requestData['last_name'],
            'email' => $requestData['email'],
            'phone' => $requestData['phone'],
            'address' => $requestData['address'],
            'city' => $requestData['city'],
            // 'pincode' => $requestData['pincode'],
            // 'landmark' => $requestData['landmark'],
            'remark' => $requestData['remark'],
            'country' => $requestData['country'],
            'total_amount'=>$total_offer_price,

        ]);

        foreach ($productItems as $key => $itemId) {
            $price = $itemId->offer_price;
            $shippingCharges = $itemId->shipping_charge;
            Item::create([
                'order_id' => $order->id,
                'product_id' => $itemId->id,
                'price'=>$price,
                'total_amount'=>$total_offer_price,
                'shipping_charge'=>$shippingCharges,
                'dimension_id'=>$dimensionIds[$key]
            ]);
        }

        return response()->json([
            'message' => 'Order created successfully',
            'order_id' => $order->id,
            'status'=>1 
        ], 201);
    }


    // public function myOrders(Request $request){
    //     $emailId = $request->email;
    //     if(!empty($emailId)){
    //        $orderData = Order::with(['items','items.product'])->where('email', $emailId)->get();
    //         return response()->json([
    //             "orders"=>$orderData,
    //             "status" => 1,
    //             'message'=>'success'
    //         ]);
    //     }else{
    //         return response()->json([
    //             "orders"=> [],
    //             "status" => 0,
    //             'message'=>'Something Went Wrong.'
    //         ]);
    //     }
    // }

    public function myOrders(Request $request)
{
    $emailId = $request->email;

    if (!empty($emailId)) {

            $orderData = Order::with(['items', 'items.product', 'items.dimension'])
                ->where('email', $emailId)
                ->get();
        
        
        
        // $shippingChargeSum = $orderData->flatMap(function ($order) {
        //     return $order->items->map(function ($item) {
        //         return $item->product->shipping_charge;
        //     });
        // })->sum();

        // $subtotalSum = $orderData->flatMap(function ($order) {
        //     return $order->items->map(function ($item) {
        //         return $item->price;
        //     });
        // })->sum();

        // $orderData->shippingChargeSum = $shippingChargeSum;
        // $orderData->subtotalSum = $subtotalSum;
        return response()->json([
            "orders" => $orderData,
            "status" => 1,
            'message' => 'success'
        ]);
    } else {
        return 'helo';
        return response()->json([
            "orders" => [],
            "status" => 0,
            'message' => 'Something Went Wrong.'
        ]);
    }
}




    public function saveEnquireForm(Request $request)
    {
        $rules = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'product_id' => 'required',
            'phone' => 'required',
            'address' => 'nullable',
            'message' => 'nullable',
        ]);

        $existingEmail = Enquire::where('email', $rules['email'])->where('product_id', $rules['product_id'])->first();

        if ($existingEmail) {
            return response()->json([
                "status" => 0,
                "message" => "Your Enquire has already been sent.",
            ]);
        }
        
        $data = new Enquire();
        $data->name = $rules['name'];
        $data->email = $rules['email'];
        $data->product_id = $rules['product_id'];
        $data->phone = $rules['phone'];
        $data->address = $rules['address'];
        $data->message = $rules['message'];
        $result = $data->save();

        if ($result) {
            return response()->json([
                "status" => 1,
                "message" => "Enquire Added Successfully!!",
            ]);
        } else {
            return response()->json([
                "status" => 0,
                "message" => "Operation Failed!!",
            ]);
        }
    }
    
       public function create_checkout_session(Request $request){
        try {
            $dimensionData = Dimension::whereIn('id', $request->dimensionIds)->get();
            // $productItems = Post::whereIn('id', $cartItems)->get();
            $amount = $request->total_offer_price; 
            $quantity = $request->quantity != "" ? $request->quantity : 1; 
            
            $ids = $request->productIds;
            $products = Post::whereIn('id', $ids)->get();



            $lineItems = [];
            foreach ($products as $key => $product) {
                $lineItems[] = [
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => [
                            'name' => $product->title,
                          //  'images' => [$product->featuredimage[0]['path']], // Add the image URL of the product
                        ],
                        'unit_amount' => ($dimensionData[$key]->offer_price + $product->shipping_charge) * 100, // Convert to cents
                    ],
                    'quantity' => 1, // You can adjust the quantity as needed
                ];
            }

           // return $lineItems;die;

           $metadata = [
                'order_id' =>  $request->order_id,
            ];
            Stripe::setApiKey(env('STRIPE_SECRET')); // Set your Stripe secret key
            
               // Check if the customer exists in Stripe
                $customer = \Stripe\Customer::all(["email" => $request->email])->data;
        
                if (count($customer) === 0) {
                    // Customer doesn't exist, create a new customer
                    $customer = \Stripe\Customer::create([
                        'email' => $request->email,
                    ]);
                } else {
                    // Customer already exists
                    $customer = $customer[0];
                }

            
            
    
            $session = \Stripe\Checkout\Session::create([
                'payment_method_types' => ['card'],
                'line_items' => [$lineItems],
                'customer' =>$customer->id,
                'metadata' => $metadata,
                'mode' => 'payment',
                'success_url' => 'https://danielhanart.com/success-payment?id='.base64_encode($request->order_id),
                'cancel_url' => 'https://danielhanart.com/cart',
            ]);
    
            return response()->json([
                'sessionId' => $session->id,
                'status'=>1,
                'message'=>'success'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => $e->getMessage(),
                'status'=>0,
                'message'=>'error'
                ], 400);
        }
    }

  
    public function generateInvoicePdf($order)
    {
        $orderData = Order::with(['items', 'items.product','items.dimension'])->where('id', $order->id)->first();
        $pdf = PDF::loadView('invoice', compact('orderData'));
        $fileName = time() . '_'.$order->id.'_invoice.pdf';
        $s3 = new S3Client([
            'credentials' => [
                'key' => env('AWS_ACCESS_KEY_ID'),
                'secret' => env('AWS_SECRET_ACCESS_KEY'),
            ],
            'region' => env('AWS_DEFAULT_REGION'),
            'version' => 'latest',
        ]);
    
        try {
            // Upload the PDF to S3 directly
            $result = $s3->putObject([
                'Bucket' => env('AWS_BUCKET'),
                'Key' => env('AWS_FOLDER_NAME') . '/' . $fileName,
                'Body' => $pdf->output(),
            ]);
    
            // Get the URL of the uploaded PDF
            $pdfUrl = $result['ObjectURL'];
            $order = Order::find($order->id);
            $order->invoice_link = $fileName;
            $order->save();
        } catch (Aws\Exception\S3Exception $e) {
            return response()->json(['error' => 'S3 upload failed'], 500);
        }
    }

        public function openpdf(){
            $orderData = Order::with(['items', 'items.product'])->where('id', 111)->first();
            return view('invoice',compact('orderData'));
        }

    
public function stripeWebhook(Request $request){
			// \Log::channel('webhook')->info(json_encode($request->all()));
			$stripeSecret = env('STRIPE_SECRET');
			$stripe = new \Stripe\StripeClient($stripeSecret);

			// This is your Stripe CLI webhook secret for testing your endpoint locally.
			$endpoint_secret = 'whsec_MYfLEiaSGuEW3pJAr0kDWG3wfSUc2X9c';

			$payload = @file_get_contents('php://input');

			$sig_header = $request->header('stripe-signature');
		    
			$event = null;
			\Log::channel('webhook')->info($payload);
    
			try {
			$event = \Stripe\Webhook::constructEvent(
				$payload, $sig_header, $endpoint_secret
			);
			} catch(\UnexpectedValueException $e) {
			// Invalid payload
			\Log::channel('webhook')->info('Unexpected');
			\Log::channel('webhook')->info($e);
			return $e;
			exit();
			} catch(\Stripe\Exception\SignatureVerificationException $e) {
				\Log::channel('webhook')->info('Invalid signature');
				\Log::channel('webhook')->info($e);
				return $e;
			// Invalid signature
			exit();
			}

			// Handle the event
			switch ($event->type) {
			case 'checkout.session.completed':
			   $sessionData = $event->data->object;
            \Log::channel('webhook')->info('Received checkout session completed event.');
            \Log::channel('webhook')->info(json_encode($sessionData));

            // Retrieve and update order information using the metadata 'order_id'
            $orderId = $sessionData->metadata->order_id;
            $order = Order::where('id', $orderId)->first();

            if ($order) {
                $this->generateInvoicePdf($order);
                $order->payment_intent_id = $sessionData->payment_intent;
                $order->currency = $sessionData->currency;
                $order->full_data = json_encode($sessionData);
                $order->payment_status = $sessionData->payment_status;
                $order->customer_id = $sessionData->customer;
                $order->save();
                Mail::to($order['email'])->send(new SendPurchaseMail($order));
                \Log::channel('webhook')->info('Order updated successfully.');
            } else {
                \Log::channel('webhook')->info('Order not found for order_id: ' . $orderId);
            }

            break;
            
			default:
				\Log::channel('webhook')->info('Received unknown event type ' . $event->type);
				return 'Received unknown event type ' . $event->type;
			}
			// return $request->all();
		}




    public function getOrderById(Request $request){
        $orderId = $request->id;
        if(!empty($orderId)){
           $orderData = Order::with(['items','items.product','items.dimension'])->where('id', $orderId)->first();
           
           $shippingChargeSum = $orderData->items->sum(function ($item) {
                return $item->product->shipping_charge;
            });

            $subtotalSum = $orderData->items->sum(function ($item) {
                return $item->price;
            });
            $orderData->shippingChargeSum = $shippingChargeSum;
            $orderData->subtotalSum = $subtotalSum;
            return response()->json([
                "orders"=>$orderData,
                "status" => 1,
                'message'=>'success'
            ]);
        }else{
            return response()->json([
                "orders"=> [],
                "status" => 0,
                'message'=>'Something Went Wrong.'
            ]);
        }
    }


    // public function getFooterData() {
    //     $data = Setting::where('name','footer_text')->first();
    //     return response()->json([
    //         "data"=> $data,
    //         "status" => 1,
    //         'message'=>'Success'
    //     ]);
    // }

    public function getFooterData() {
        $slugs = [
            'footer_text',
            'about_us',
            'contact_information',
            'privacy_policy',
            'terms_conditions',
            'adorn_description_data',
            'acquire_description_data',
            'art_description_data',
            'contact_description_data',
            'about_us_image',
            'home_category_color',
            'home_newsletter_color',
            'why_we_use_text'
        ];
    
        $data = Setting::whereIn('slug', $slugs)->pluck('value', 'slug')->all();
        $about_us_profile = Setting::where('slug', 'about_us_image')->pluck('image')->first();
        $why_we_use_text_video = Setting::where('slug', 'why_we_use_text')->pluck('image')->first();
        $data['bio_image'] = $about_us_profile['path'];
        $data['why_we_use_text_video'] = $why_we_use_text_video;
        unset($data['about_us_image']);
        return response()->json([
            "data"=> $data,
            "status" => 1,
            'message'=>'Success'
        ]);
    }




}
