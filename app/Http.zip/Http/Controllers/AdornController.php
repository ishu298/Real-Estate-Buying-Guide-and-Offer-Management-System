<?php

namespace App\Http\Controllers;

use App\Models\Tag;
use App\Models\Post;
use App\Models\User;
use App\Models\Adorn;
use App\Models\Setting;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;


class AdornController extends Controller
{
    public function list()
    {
        $data = Adorn::orderBy('created_at', 'DESC')->get();
        return view('admin.adorn.adron_list', ['lists' => $data]);
    }

    public function adron_detail($id){
        $data = Adorn::find($id);
        return view('admin.adorn.adron_detail', ['data' => $data]);
    }

    public function delete_adorn($id)
    {
        $adorn = Adorn::find($id); 
        if ($adorn) {
            $adorn->delete();
        } else {
            return Redirect::back()->with('error', 'Adorn not found.');
        }
        return redirect()->route('admin.adorn_list');
    }

}
