<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LiteratureCategory;

class LiteratureCategoryController extends Controller
{
    public function list()
    {
        $data = LiteratureCategory::orderBy('order_number','ASC')->get();
        return view('admin.literatureCategory.list', ['lists' => $data]);
    }

    public function add(Request $request)
    {
        $rules = $request->validate([
            'title' => 'required',
            'slug' => 'required'
        ]);

        $data = new LiteratureCategory();
        $data->title = $rules['title'];
        $data->slug = $rules['slug'];
        $data->save();

        return redirect()->route('admin.literature_category_list');
    }

    public function edit($id)
    {
        $data = LiteratureCategory::find($id);
        return view('admin.literatureCategory.edit', ['edits' => $data]);
    }

    public function update(Request $request)
    {
        $rules = $request->validate([
            'title' => 'required',
            'slug' => 'required'
        ]);

        $data = LiteratureCategory::find($request->id);
        $data->title = $rules['title'];
        $data->slug = $rules['slug'];
        $data->save();

        return redirect()->route('admin.literature_category_list');
    }

    public function destroy($id)
    {
        $data = LiteratureCategory::find($id);
        $data->delete();
        return redirect()->route('admin.literature_category_list');
    }

    public function literature_update_order(Request $request)
    {
        $sortedIDs = $request->input('sorted_data');
        foreach ($sortedIDs as $index => $id) {
            LiteratureCategory::where('id', $id)->update(['order_number' => $index + 1]);
        }
        return response()->json(['success' => true]);
    }
}
