<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Post;
use App\Models\User;
use App\Models\Event;
use App\Models\Order;
use App\Models\Category;
use App\Models\Literature;

class CountController extends Controller
{
    public function index()
    {
        $data['usercount'] = User::all()->count();
        $data['categorycount'] = Category::all()->count();
        $data['literaturecount'] = Literature::all()->count();
        $data['eventcount'] = Event::all()->count();
        $data['postcount'] = Post::all()->count();
        $latestPosts = Post::latest()->take(4)->get();
        $startDate = Carbon::now()->subDays(7);
        $endDate = Carbon::now();

        $orderDataLastSevenDays = Order::with(['items', 'items.product'])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->get();

        return view('dashboard',compact('data','orderDataLastSevenDays','latestPosts'));
    }
}
