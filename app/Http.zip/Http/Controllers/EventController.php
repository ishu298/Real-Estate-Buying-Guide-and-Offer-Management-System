<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Event;
use App\Models\Category;
use App\Models\Literature;
use Illuminate\Http\Request;
use App\Models\LiteratureCategory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class EventController extends Controller
{
    public function list()
    {
        $currentUser = Auth::user();
        $data = Event::orderBy('order_number','ASC')->get();
        return view('admin.events.list', ['lists' => $data]);
    }

    public function add()
    {
        $data1 = LiteratureCategory::all();
        return view('admin.events.add', ['lists1' => $data1]);
    }

 
    public function store(Request $request)
    {
        ini_set('upload_max_filesize', '200M');
        ini_set('post_max_size', '200M');

        $imagePaths = [];
        if ($request->hasFile('image')) {
            foreach ($request->file('image') as $key => $image) {
                $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));

                // $imageName = time() . '_' . $key . '.' . $image->getClientOriginalExtension();
                // $image->move(('featured-image'), $imageName);
                $imagePaths[] = $imageName;
            }
        }
        
        $data = [
            'name' =>$request->name,
            'date' =>$request->date,
            'time' =>$request->time,
            'venue' => $request->venue,
            'description' =>$request->description,
            'image' =>$imagePaths,
            'slug' => Str::slug($request['name']),
        ];
        $event = Event::create($data);      
        return redirect()->route('admin.event_list')->with('success', 'Event added successfully!');
    }





    public function edit($id)
    {
        $data = Event::find($id);
        return view('admin.events.edit', ['edits' => $data]);
    }

    public function update(Request $request)
    {   
        ini_set('upload_max_filesize', '200M');
        ini_set('post_max_size', '200M');

        $data = Event::find($request->id);

        if ($request->hasFile('image')) {
            $imagePaths = [];
            foreach ($request->file('image') as $key => $image) {
                $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
                // $imageName = time() . '_' . $key . '.' . $image->getClientOriginalExtension();
                // $image->move(('featured-image'), $imageName);
                $imagePaths[] = $imageName;
            }


              // delete old images from folder and db
              if (!empty($data->image) && $data->image != "") {
                foreach ($data->image as $key => $value) {
                    // dd($value);
                    deleteImageFromS3($value['name'], env('AWS_FOLDER_NAME') );
                }
            }
            // dd('sorry');
            $data->name = $request->name;
            $data->date = $request->date;
            $data->time = $request->time;
            $data->venue = $request->venue;
            $data->description = $request->description;
            $data->image = $imagePaths;
            $data->slug = Str::slug($request->name);
            $data->save();

        } else {
            $data = Event::find($request->id);
            $data->name = $request->name;
            $data->date = $request->date;
            $data->time = $request->time;
            $data->venue = $request->venue;
            $data->slug = Str::slug($request->name);
            $data->description = $request->description;
            $data->save();
        }

        return redirect()->route('admin.event_list');
    }

    public function destroy($id)
    {
        $data = Event::find($id);
        $data->delete();
        return redirect()->route('admin.event_list');
    }

    
    public function event_order_update(Request $request)
    {
        $sortedIDs = $request->input('sorted_data');
        foreach ($sortedIDs as $index => $id) {
            Event::where('id', $id)->update(['order_number' => $index + 1]);
        }
        return response()->json(['success' => true]);
    }


}
