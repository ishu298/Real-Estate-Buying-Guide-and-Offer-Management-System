<?php

namespace App\Http\Controllers;

use App\Models\Tag;
use App\Models\Post;
use App\Models\User;
use App\Models\Contact;
use App\Models\Enquire;
use App\Models\Setting;
use App\Models\Category;
use App\Models\ContactReply;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;


class UserController extends Controller
{
    public function list()
    {
        $currentUser = Auth::user();
        $data = User::orderBy('created_at', 'DESC')->get();
        // dd($data);
        return view('admin.user.list', ['lists' => $data]);
    }

    public function add()
    {
        return view('admin.user.add');
    }

   
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8'
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors());
        }

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ]);

        return redirect('user/list');
    }
    

    public function edit($id)
    {
        $data = User::find($id);
        return view('admin.user.edit', ['edits' => $data]);
    }

    public function update(Request $request)
{
    // dd($request->all());
    $validator = Validator::make($request->all(), [
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users,email,'.$request->user_id,
        'password' => 'nullable|string|min:8' // Updated to allow password to be nullable
    ]);

    if ($validator->fails()) {
        return response()->json($validator->errors());
    }

    $user = User::findOrFail($request->user_id);

    // Update name and email
    $user->name = $request->name;
    $user->email = $request->email;

    // Update password if provided
    if (!empty($request->password)) {
        $user->password = Hash::make($request->password);
    }

    $user->save();

    return redirect('user/list');
}


    public function destroy($id)
    {
        $data = User::find($id);
        $data->delete();
        return redirect('user/list');
    }

    public function cms_setting(){
        $lists = Setting::get();
        return view('admin.user.cmd_setting',compact('lists'));
    }



    public function store_cms_setting(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8'
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors());
        }

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ]);

        return redirect('user/list');
    }
    
    public function add_cmd_setting()
    {
        return view('admin.user.add_cmd_setting');
    }


    public function contact_list(){
        $lists = Contact::orderBy('created_at',"DESC")->get();
        return view('admin.user.contact_list',compact('lists'));
    }

    public function contact_all_reply($id){
        $lists = Contact::with('contact_replies')->orderBy('created_at',"DESC")->find($id);
        return view('admin.user.contact_all_reply',compact('lists'));
    }
    

    public function contact_detail($id){
        $data = Contact::find($id);
        return view('admin.user.contact_detail',compact('data'));
    }


    public function send_contact_reply(Request $request){
        $data = Contact::find($request->contact_id);
        ContactReply::create([
            "reply_text" => $request->reply_text,
            "contact_id" => $request->contact_id,
        ]);
        return redirect('request/contact');
    }


    public function delete_contact($id)
    {
        $contact = Contact::find($id);
    
        if ($contact) {
            $contact->delete();
        } else {
            return Redirect::back()->with('error', 'Contact not found.'); // Redirect back with an error message
        }
    
        return redirect('request/contact');
    }

    public function delete_contact_reply($id,$contact_id)
    {
        $contact = ContactReply::find($id); 
        if ($contact) {
            $contact->delete();
        } else {
            return Redirect::back()->with('error', 'Contact not found.'); // Redirect back with an error message
        }
    
        return redirect()->route('admin.contact_all_reply', ['id' => $contact_id]);
    }


    

    public function enquire_list(){
        $lists = Enquire::with('product')->orderBy('created_at',"DESC")->get();
        return view('admin.user.enquire_list',compact('lists'));
    }

    public function enquire_detail($id){
        $data = Enquire::with('product')->find($id);
        return view('admin.user.enquire_detail',compact('data'));
    }


    public function delete_enquire($id)
    {
        $contact = Enquire::find($id);
    
        if ($contact) {
            $contact->delete();
        } else {
            return Redirect::back()->with('error', 'Contact not found.'); // Redirect back with an error message
        }
    
        return redirect('request/enquire');
    }

}
