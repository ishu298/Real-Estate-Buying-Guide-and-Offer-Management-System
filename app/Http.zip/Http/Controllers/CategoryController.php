<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    public function list()
    {
    $data = Category::orderBy('order_number','ASC')->get();
        return view('admin.category.list', ['lists' => $data]);
    }

    public function add(Request $request)
    {
        $rules = $request->validate([
            'title' => 'required',
            'slug' => 'required',
            // 'category_img' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048' // Validate the image
        ]);
    
        if ($request->hasFile('category_img')) {
            $image = $request->file('category_img');
            $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
            // $imageName = time().'.'.$request->category_img->getClientOriginalExtension();
            // $request->category_img->move(public_path('featured-image'), $imageName);
        }
        $data = new Category();
        $data->title = $rules['title'];
        $data->slug = $rules['slug'];
        $data->image = $imageName ?? null; 
        $data->save();
    
        return redirect('category/list');
    }
    
    public function edit($id)
    {
        $data = Category::find($id);
        return view('admin.category.edit', ['edits' => $data]);
    }


    public function update(Request $request)
{
    $rules = $request->validate([
        'title' => 'required',
        'slug' => 'required',
        // 'category_img' => 'image|mimes:jpeg,png,jpg,gif|max:2048' // Validation for image upload
    ]);

    $data = Category::find($request->id);
    $data->title = $rules['title'];
    $data->slug = $rules['slug'];

    if ($request->hasFile('category_img')) {
        $image = $request->file('category_img');
        $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
        // delete old images from folder and db
        if (!empty($data->image) && $data->image != "") {
            $result =  deleteImageFromS3($data->image['name'], env('AWS_FOLDER_NAME') );
        }
        $data->image = $imageName;
    }



    $data->save();

    return redirect('category/list');
}



    public function destroy($id)
    {
        $data = Category::find($id);
        $data->delete();
        return redirect('category/list');
    }

    public function category_order_update(Request $request)
    {
        $sortedIDs = $request->input('sorted_data');
        foreach ($sortedIDs as $index => $id) {
            Category::where('id', $id)->update(['order_number' => $index + 1]);
        }
        return response()->json(['success' => true]);
    }

    
}
