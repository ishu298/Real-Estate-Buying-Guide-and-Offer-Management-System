<?php

namespace App\Http\Controllers;

use App\Models\Tag;
use App\Models\Post;
use App\Models\User;
use App\Models\Order;
use App\Models\Contact;
use App\Models\Enquire;
use App\Models\Setting;
use App\Models\Category;
use App\Models\ContactReply;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;


class CheckoutController extends Controller
{
    public function order_list()
    {
        $orderData = Order::with(['items','items.product'])->orderBy('created_at', 'DESC')->get();
        return view('admin.checkout.oder_list', ['lists' => $orderData]);
    }


    public function order_detail($id)
    {
        $orderData = Order::with(['items','items.product'])->find($id);
        return view('admin.checkout.order_detail', ['orderData' => $orderData]);
    }

 

}
