<?php

namespace App\Http\Controllers;

use Image;
use App\Models\Post;
use App\Models\User;
use App\Models\Category;
use App\Models\Dimension;
use App\Models\Literature;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
// use App\Helpers\AwsHelpers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;


class PostController extends Controller
{
    public function list()
    {
        $currentUser = Auth::user();
        $data = Post::with('dimension')->where('user_id', '=', $currentUser->id)->orderBy('order_number', 'ASC')->get();
        return view('admin.post.list', ['lists' => $data]);
    }

    public function add()
    {
        $data1 = Category::all();
        $literatures = Literature::all();
        // $data2 = Tag::all();
        return view('admin.post.add', ['lists1' => $data1, 'literatures' => $literatures]);
    }

    // public function store(Request $request)
    // {
    //     ini_set('upload_max_filesize', '64M');
    //     ini_set('post_max_size', '64M');

    //     $rules = $request->validate([
    //         'title' => 'required',
    //         'body' => 'required|string',
    //         'dimensions'=> 'nullable',
    //         'offer_price' => 'nullable',
    //         'selling_price' => 'nullable',
    //         'shipping_charge' => 'nullable',
    //         'literature_id' => 'nullable',
    //         'featuredimages.*' => 'required|image|mimes:jpeg,png,jpg,gif,webp,svg,tiff,bmp', // Validate each image file
    //     ]);
    //     $imagePaths = [];
    //     $waterMarkImagePaths = [];
    //     if ($request->hasFile('featuredimages')) {
    //         foreach ($request->file('featuredimages') as $key => $image) {
    //             $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
    //             $imagePaths[] = $imageName;
    //         }
    //     }

    //     $data = new Post();
    //     $data->user_id = Auth::id();
    //     $data->title = $rules['title'];
    //     $data->slug = Str::slug($rules['title']);
    //     $data->body = $rules['body'];
    //     $data->dimensions = $rules['dimensions'] ?? '';
    //     $data->literature_id = $rules['literature_id'];
    //     $data->selling_price = $rules['selling_price'];
    //     $data->shipping_charge = $rules['shipping_charge'];
    //     $data->offer_price = $rules['offer_price'];
    //     $data->status = $request->status ? $request->status : 0;
    //     $data->featuredimage = $imagePaths;
    //     $data->watermarkimage = $waterMarkImagePaths;
    //     $data->save();
    //     $data->categories()->sync($request->categories);
    //     // $data->tags()->sync($request->tags);

    //     return redirect('product/list');
    // }


    public function store(Request $request)
    {
        ini_set('upload_max_filesize', '64M');
        ini_set('post_max_size', '64M');

        // $rules = $request->validate([
        //     'title' => 'required',
        //     'body' => 'required|string',
        //     'dimensions'=> 'nullable',
        //     'offer_price' => 'nullable',
        //     'selling_price' => 'nullable',
        //     'shipping_charge' => 'nullable',
        //     'literature_id' => 'nullable',
        //     'featuredimages.*' => 'required|image|mimes:jpeg,png,jpg,gif,webp,svg,tiff,bmp',
        //     'other_images.*' => 'required|image|mimes:jpeg,png,jpg,gif,webp,svg,tiff,bmp',
        //     'order_number' => 'nullable',
        // ]);

    
        $rules = $request->validate([
            'title' => 'required',
            'body' => 'required|string',
            'dimensions.*.selling_price' => 'nullable|numeric',
            'dimensions.*.offer_price' => 'nullable|numeric',
            'dimensions.*.shipping_charge' => 'nullable|numeric',
            'dimensions.*.dimensions' => 'nullable|string',
            'literature_id' => 'nullable',
            'featuredimages.*' => 'required|image|mimes:jpeg,png,jpg,gif,webp,svg,tiff,bmp',
            'other_images.*' => 'required|image|mimes:jpeg,png,jpg,gif,webp,svg,tiff,bmp',
            'order_number' => 'nullable',
        ]);
    


        $imagePaths = [];
        $other_images = [];
        if ($request->hasFile('featuredimages')) {
            $counter = 0; 
            foreach ($request->file('featuredimages') as $key => $image) {
                if ($counter < 2) { 
                $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
                $imagePaths[] = $imageName;
                $counter++;
            }
            }
        }

        if ($request->hasFile('other_images')) {
            foreach ($request->file('other_images') as $key => $image) {
                $other_images_imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
                $other_images[] = $other_images_imageName;
            }
        }

        $data = new Post();
        $data->user_id = Auth::id();
        $data->title = $rules['title'];
        $data->slug = Str::slug($rules['title']);
        $data->body = $rules['body'];
        $data->literature_id = $rules['literature_id'];
        // $data->dimensions = $rules['dimensions'] ?? '';
        // $data->selling_price = $rules['selling_price'];
        // $data->shipping_charge = $rules['shipping_charge'];
        // $data->offer_price = $rules['offer_price'];
        $data->status = $request->status ? $request->status : 0;
        $data->order_number = $request->order_number;
        $data->featuredimage = $imagePaths;
        $data->other_images = $other_images;
        $data->save();
        $data->categories()->sync($request->categories);
        // $data->tags()->sync($request->tags);


         // Save dimensions
         if ($request->filled('dimensions')) {
            foreach ($request->dimensions['selling_price'] as $key => $sellingPrice) {
                $dimension = new Dimension();
                $dimension->post_id = $data->id;
                $dimension->selling_price = $sellingPrice;
                $dimension->offer_price = $request->dimensions['offer_price'][$key];
                $dimension->shipping_charge = $request->dimensions['shipping_charge'][$key];
                $dimension->dimensions = $request->dimensions['dimensions'][$key];
                $dimension->save();
            }
        }
        


        return redirect('product/list');
    }


    public function edit($id)
    {
        $data = Post::with('dimension')->find($id);
        $data1 = Category::all();
        $literatures = Literature::all();
        return view('admin.post.edit', ['edits' => $data, 'categories' => $data1, 'literatures' => $literatures]);
    }


    public function deleteDimension($dimensionId)
{
    $dimension = Dimension::findOrFail($dimensionId);
    $dimension->delete();
    
    return response()->json(['success' => true]);
}

    public function update(Request $request)
    {
  
        ini_set('upload_max_filesize', '64M');
        ini_set('post_max_size', '64M');
        $rules = $request->validate([
            'title' => 'required',
            'body' => 'required',
            'dimensions.*.selling_price' => 'nullable|numeric',
            'dimensions.*.offer_price' => 'nullable|numeric',
            'dimensions.*.shipping_charge' => 'nullable|numeric',
            'dimensions.*.dimensions' => 'nullable|string',
            'literature_id' => 'nullable',
            'featuredimage' => 'nullable',
            'order_number' => 'nullable',

        ]);

        if ($request->hasFile('featuredimages') || $request->hasFile('other_images')) {
            $data = Post::find($request->id);
            $imagePaths = [];
   
            if ($request->hasFile('featuredimages')) {
            foreach ($request->file('featuredimages') as $key => $image) {
                $imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
                $imagePaths[] = $imageName;
            }

            $prevImages = unserialize($data->getRawOriginal('featuredimage'));
            $newFeatureImages = array_merge($prevImages,$imagePaths);

            $data->featuredimage = $newFeatureImages;
        }

        $newOtherImages = [];
            if ($request->hasFile('other_images')) {
            $other_images = [];
            if ($request->hasFile('other_images')) {
                foreach ($request->file('other_images') as $key => $image) {
                    $other_images_imageName = uploadImageToS3($image, env('AWS_FOLDER_NAME'));
                    $other_images[] = $other_images_imageName;
                }
            }
            
                if(count($data->other_images)  > 0){
                $prevOtherImages = unserialize($data->getRawOriginal('other_images'));   
                $newOtherImages = array_merge($prevOtherImages,$other_images);
                }else{
                $newOtherImages = $other_images;
                }

                    $data->other_images = $newOtherImages;
          }

         


            $data->title = $rules['title'];
            $data->slug = Str::slug($rules['title']);
            // $data->selling_price = $rules['selling_price'];
            $data->literature_id = $rules['literature_id'];
            // $data->offer_price = $rules['offer_price'];
            // $data->shipping_charge = $rules['shipping_charge'];
            $data->body = $rules['body'];
            // $data->dimensions = $rules['dimensions'] ?? '';
            $data->status = $request->status ? $request->status : 0;
            $data->order_number = $request->order_number;
            // $data->featuredimage = $imageName;
            $data->save();

            $data->categories()->sync($request->categories);
            // $data->tags()->sync($request->tags);
               // Save or update dimensions
          if ($request->filled('dimensions')) {
            foreach ($request->dimensions['selling_price'] as $key => $sellingPrice) {
           if(isset($request->dimensions['dimension_id'][$key])) {
               $dimension = Dimension::find($request->dimensions['dimension_id'][$key]);
           } else {
               // If dimension ID is not provided, create new dimension
               $dimension = new Dimension();
               $dimension->post_id = $data->id;
           }
           // Update dimension fields
           $dimension->selling_price = $sellingPrice;
           $dimension->offer_price = $request->dimensions['offer_price'][$key];
           $dimension->shipping_charge = $request->dimensions['shipping_charge'][$key];
           $dimension->dimensions = $request->dimensions['dimensions'][$key];
           $dimension->save();
       }
   }


        } else {
            $data = Post::find($request->id);
            $data->user_id = Auth::id();
            $data->title = $rules['title'];
            $data->slug = Str::slug($rules['title']);
            $data->body = $rules['body'];
            $data->literature_id = $rules['literature_id'];
            // $data->dimensions = $rules['dimensions'] ?? '';
            // $data->selling_price = $rules['selling_price'];
            // $data->offer_price = $rules['offer_price'];
            // $data->shipping_charge = $rules['shipping_charge'];
            $data->status = $request->status ? $request->status : 0;
            $data->order_number = $request->order_number;
            $data->save();
            $data->categories()->sync($request->categories);
            // $data->tags()->sync($request->tags);

            // Save or update dimensions
          if ($request->filled('dimensions')) {
             foreach ($request->dimensions['selling_price'] as $key => $sellingPrice) {
            if(isset($request->dimensions['dimension_id'][$key])) {
                $dimension = Dimension::find($request->dimensions['dimension_id'][$key]);
            } else {
                // If dimension ID is not provided, create new dimension
                $dimension = new Dimension();
                $dimension->post_id = $data->id;
            }
            // Update dimension fields
            $dimension->selling_price = $sellingPrice;
            $dimension->offer_price = $request->dimensions['offer_price'][$key];
            $dimension->shipping_charge = $request->dimensions['shipping_charge'][$key];
            $dimension->dimensions = $request->dimensions['dimensions'][$key];
            $dimension->save();
        }
    }


        }

        return redirect('product/list');
    }

    public function destroy($id)
    {
        $data = Post::find($id);
        $data->delete();
        return redirect('product/list');
    }


    public function delete_image($id,$name){
        $data = Post::find($id);
        $images = unserialize($data->getRawOriginal('featuredimage'));
        
        $indexToDelete = null;
        foreach ($images as $index => $image) {
            if ($image === $name) {
                deleteImageFromS3($name, env('AWS_FOLDER_NAME') );
                $indexToDelete = $index;
                break;
            }
        }
        // If a matching image is found, unset it
        if ($indexToDelete !== null) {
            unset($images[$indexToDelete]);
        }
        $data->featuredimage = $images;
        $data->save();
        return 1;
    }


    
    public function delete_other_image($id,$name){
        $data = Post::find($id);
        $images = unserialize($data->getRawOriginal('other_images'));
        
        $indexToDelete = null;
        foreach ($images as $index => $image) {
            if ($image === $name) {
                deleteImageFromS3($name, env('AWS_FOLDER_NAME') );
                $indexToDelete = $index;
                break;
            }
        }
        // If a matching image is found, unset it
        if ($indexToDelete !== null) {
            unset($images[$indexToDelete]);
        }
        $data->other_images = $images;
        $data->save();
        return 1;
    }

    public function check_duplicate_order($val =""){
        $data = Post::where('order_number',$val)->count();   
        return $data;
    }


    public function post_update_order(Request $request)
    {
        $sortedIDs = $request->input('sorted_data');
        foreach ($sortedIDs as $index => $id) {
            Post::where('id', $id)->update(['order_number' => $index + 1]);
        }
        return response()->json(['success' => true]);
    }
    



}
