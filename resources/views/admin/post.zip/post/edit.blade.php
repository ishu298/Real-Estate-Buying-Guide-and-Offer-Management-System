@extends('layouts.master')
@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Art Product Form</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Art Product Form</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-xl-12 col-lg-12 col-sm-12">
                    <!-- general form elements -->
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title">Add Art Product</h3>
                        </div>
                    <form class="form-vertical p-4" action="{{route('admin.update_product')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input name="id" type="hidden" class="form-control" id="id" value="{{$edits['id']}}">
                        <div class="form-group mb-4">
                            <label class="control-label">Title</label>
                            <input type="text" name="title" class="form-control" value="{{$edits['title']}}">
                        </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="selling_price">Selling Price ($)</label>
                                    <input type="number" class="form-control" id="selling_price" value="{{$edits['selling_price']}}" name="selling_price" required
                                        placeholder="Enter Selling Price">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="offer_price">Offer Price ($)</label>
                                    <input type="number" class="form-control" id="offer_price" value="{{$edits['offer_price']}}"  name="offer_price" required
                                        placeholder="Enter Offer Price">
                                </div>
                            </div>
                        </div>


                        <div class="form-group mb-4 d-none">
                            <label class="control-label">Slug</label>
                            <input type="text" name="slug" class="form-control" value="{{$edits['slug']}}">
                        </div>

                        <div class="n-chk form-group mb-4">
                            <label class="new-control new-checkbox checkbox-success">
                                <input type="checkbox" class="new-control-input" name="status" value="1" @if ($edits->status == 1)
                                {{ 'checked' }}
                                @endif>
                                <span class="new-control-indicator"></span>Publish
                            </label>
                        </div>

                            <div class="row">

                        <div class="col-lg-6">

                      
                        <div class="form-group mb-4">
                            <label class="control-label">Categories</label>
                            <div class="select2-purple">
                                <select class="select2" multiple="multiple" name="categories[]" ata-dropdown-css-class="select2-purple"
                                style="width: 100%;">
                                @foreach ($categories as $category)
                                <option value="{{ $category->id}}" @foreach ($edits->categories as $postCategory)
                                    @if ($postCategory->id == $category->id)
                                    selected
                                    @endif
                                    @endforeach
                                    >{{ $category->title}}</option>
                                @endforeach
                            </select>
                        </div>

                    </div>
                </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="control-label">Literature</label>
                                    <select class="form-control" 
                                        style="width: 100%;" name="literature_id">
                                        @foreach ($literatures as $literature)
                                            <option value="{{ $literature->id }}" {{$edits->literature_id == $literature->id ? 'selected' :""}}>{{ $literature->title }}</option>
                                        @endforeach
                                    </select>
                            </div>

                        </div>
                    </div>
                      
                </div>
                        <div class="form-group mb-4">
                            <label class="control-label">Content</label>
                            <textarea id="summernote" name="body" height="40">{{$edits['body']}}</textarea>
                        </div>


                        <div class="row">
                            {{-- @dd($edits->featuredimage) --}}
                            @foreach($edits->featuredimage as $image)
                                <div class="col-lg-2 my-2">
                                    <img src="{{$image['path']}}" alt="Featured Image" width="130" height="130">
                                </div>
                            @endforeach
                        </div>
                        

                        <div class="custom-file-container" data-upload-id="myImages">
                            {{-- <label>Upload (Multiple Files) <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Images">x</a></label> --}}
                            <label class="custom-file-container__custom-file">
                                <input type="file" class="custom-file-container__custom-file__custom-file-input" accept="image/*" name="featuredimages[]" multiple>
                                <span class="custom-file-container__custom-file__custom-file-control"></span>
                            </label>
                            <div class="custom-file-container__image-preview"></div>
                        </div>
                        
                        
                        <input type="submit" value="Submit" class="btn btn-primary ml-3 mt-3">
                    </form>
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>
</section>

@endsection