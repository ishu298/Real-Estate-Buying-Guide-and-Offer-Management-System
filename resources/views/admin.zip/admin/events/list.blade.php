@extends('layouts.master')
@section('content')
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <a href="{{route('admin.add_event')}}"><button type="button" class="btn btn-primary mb-2 m-3">
                    Add New Event
                </button></a>

            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>id</th>
                             {{-- <th>Posted By</th> --}}
                            <th>Title</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Image</th>
                            <th>Event Venue</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="sortable">
                        <?php $Sno = 1; ?>
                        @foreach ($lists as $list)
                        <tr id="{{ $list['id'] }}" class="sortable-row">
                                <td>{{ $Sno }}</td>
                                <td>{{ $list['name'] }}</td>
                                <td>{{ $list['date'] }}</td>
                                <td>{{ $list['time'] }}</td>
                                <td>
                                
                                    {{-- @dd(json_decode($list['image'])) --}}
                                    @if($list['image'] != "" && !empty($list['image'] && !empty($list['image'][0])))
                                  
                                    @foreach($list['image'] as $data)
                                      <img src="{{ $data['path'] }}" alt="" width="50" height="50">
                                      @endforeach
                                  @endif
                                
                                    </td>
                                <td>{{ $list['venue'] }}</td>
                                <td>{{ $list['description']  !="" ?  substr($list['description'],0,20).'...' : '-' }}</td>
                            
                                <td>{{ $list['updated_at'] }}</td>
                                    <td>
                                    <a class="btn btn-success" href="{{ route('admin.edit_event', ['id' => $list['id']]) }}">Edit</a>
                                    <a class="btn btn-danger" href="{{ route('admin.destroy_event', ['id' => $list['id']]) }}"
                                        onclick="return confirm('Are you sure?');">Delete</a>
                                </td>
                            </tr>
                            <?php $Sno++; ?>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script>
    $(function() {
        $("#sortable").sortable({
            update: function(event, ui) {
                var sortedData = $(this).sortable('toArray');
                console.log('sortedData',sortedData);
                $.ajax({
                    url: '{{ route("admin.event_order_update") }}',
                    method: 'POST',
                    data: {
                        sorted_data: sortedData,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        // Handle success if needed
                        console.log(response);
                    },
                    error: function(xhr, status, error) {
                        // Handle error if needed
                        console.error(xhr.responseText);
                    }
                });
            }
        });
        $("#sortable").disableSelection();
    });
</script>

@endsection
