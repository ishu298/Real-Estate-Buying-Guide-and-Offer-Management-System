@extends('layouts.master')
@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Event Form</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Event Form</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-xl-12 col-lg-12 col-sm-12">
                    <!-- general form elements -->
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title">Edit Event</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form action="{{route('update_event')}}" method="POST" enctype="multipart/form-data" class="dropzone"
                            id="my-awesome-dropzone">
                            @csrf
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="postTitleInput">Title</label>
                                    <input type="text" class="form-control" id="postTitleInput" name="name"  value="{{$edits->name}}"  required
                                        placeholder="Enter title here">
                                </div>
                               

                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="postTitleInput">Event Date</label>
                                                <input type="date" class="form-control" id="postTitleInput" value="{{$edits->date}}" name="date" required
                                                   >
                                            </div>
                                        </div>
                                        <input type="hidden" name="id" value="{{$edits->id}}">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="postTitleInput">Event Time</label>
                                                <input type="time" class="form-control" id="postTitleInput"  value="{{$edits->time}}" name="time" required
                                                   >
                                            </div>
                                        </div>
                                    </div>

                                <div class="form-group">
                                    <label for="postTitleInput">Event Venue</label>
                                    <input type="text" class="form-control" id="postTitleInput"  value="{{$edits->venue}}" name="venue" required
                                        placeholder="Enter Venue Details">
                                </div>
                               
                                
                                <div class="card card-outline card-info">
                                    <div class="card-header">
                                        <h3 class="card-title">
                                            Event Description
                                        </h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <textarea id="summernote" name="description">
                                            {{$edits->description ? $edits->description : 'Enter Description'}}
                                         </textarea>
                                    </div>
                                </div>

                                <div class="card card-default">
                                    <div class="card-header">
                                        <h3 class="card-title">Event Image</h3>
                                    </div>

                                    <div class="row my-2 mx-3">
                                        @foreach($edits->image as $data)
                                            <div class="col-lg-2">
                                                <img src="{{$data['path']}}" alt="Featured Image" width="130" height="130">
                                            </div>
                                        @endforeach
                                    </div>

                                    <div class="form-group">
                                        <div class="input-group card-body">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="exampleInputFile"
                                                    name="image[]" multiple>
                                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                            </div>
                                            <div class="input-group-append">
                                                <span class="input-group-text">Upload</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $('#postTitleInput').keyup(function() {
            var replaceSpace = $(this).val();
            var result = replaceSpace.replace(/\s/g, "-").toLowerCase();
            $("#postSlugInput").val(result);
        });
    </script>
@endsection
