@extends('layouts.master')
@section('content')
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <a href="{{route('admin.order_list')}}"><button type="button" class="btn btn-primary mb-2 m-3">
                    Back
                </button></a>

            <div class="card-body">
                <table  class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <td>{{ $orderData->first_name }}</td>
                        </tr>
                        <tr>
                            <th>Last Name</th>
                            <td>{{ $orderData->last_name }}</td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>{{ $orderData->email }}</td>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <td>{{ $orderData->phone }}</td>
                        </tr>
                        <tr>
                            <th>Total Amount</th>
                            <td>${{ $orderData->total_amount }}</td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td>{{ $orderData->address.', '.$orderData->city.', '.$orderData->pincode.', '.$orderData->citypincode.', '.$orderData->country }}</td>
                        </tr>
                    
                        <tr>
                            <th>Remark</th>
                            <td>{{ $orderData->remark }}</td>
                        </tr>

                        <tr>
                            <th>Added date</th>
                            <td>{{ $orderData->created_at }}</td>
                        </tr>
                       
                    </thead>
                </table>




                <table  class="table table-bordered table-striped my-3">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Product Title</th>
                            <th>Product Price</th>
                            <th>Quantity</th>
                            <th>Dimension</th>
                            <th>Product Images</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php $Sno = 1; ?>
                        @foreach ($orderData->items as $items)
                            <tr>
                                <td>{{ $Sno }}</td>
                                <td>{{ $items->product->title }}</td>
                                <td>${{$items->price}}</td>
                                <td>{{$items->quantity}}</td>
                                <td>{{ $items->dimension->dimensions }}</td>
                                <td>
                                    @foreach($items->product->featuredimage as $images)
                                    <img src="{{$images['path']}}" alt="" srcset="" width="100" height="100">
                                    @endforeach
                                </td>
                            </tr>
                            <?php $Sno++; ?>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
