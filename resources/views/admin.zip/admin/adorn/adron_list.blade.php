@extends('layouts.master')
@section('content')
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
       

            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Added date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $Sno = 1; ?>
                        @foreach ($lists as $list)
        
                            <tr>
                                <td>{{ $Sno }}</td>
                                <td>{{ $list->name }}</td>
                                <td>{{ $list->email }}</td>
                                <td>{{ $list->phone }}</td>
                            
                                <td>{{ $list->created_at }}</td>
                                <td>
                                    <a class="btn btn-success" href="{{ route('admin.adron_detail', ['id' => $list['id']]) }}"><i class="fa fa-eye"></i></a>  
                                    <a class="btn btn-danger" href="{{ route('admin.delete_adorn', ['id' => $list['id']]) }}"
                                        onclick="return confirm('Are you sure?');">Delete</a>
                                </td>
                            </tr>
                            <?php $Sno++; ?>
                        @endforeach
                    </tbody>
                </table>
            
            </div>
        </div>
    </div>
@endsection
