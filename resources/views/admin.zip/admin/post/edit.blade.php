@extends('layouts.master')
@section('content')
    <style>
        /* .delete-dimension {
            position: absolute;
            right: -4px;
            top: -11px;
            cursor: pointer;
        } */

        .delete-image {
            position: relative;
            right: 5%;
            top: 12px;
            background-color: red;
            color: white;
            padding: 5px;
            cursor: pointer;
            border-radius: 4px;
            width: 30px;
            height: 30px;
            color: #fff;
        }

        .img-container {
            position: relative;
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .img-container img {
            width: 100%;
            /* Make the image take 100% width of its container */
            height: auto;
            /* Maintain the aspect ratio of the image */
            display: block;
        }

        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type="number"] {
            -moz-appearance: textfield;
            /* Firefox */
        }
    </style>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Art Product Form</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Art Product Form</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-xl-12 col-lg-12 col-sm-12">
                    <!-- general form elements -->
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title">Add Art Product</h3>
                        </div>
                        <form class="form-vertical p-4" action="{{ route('admin.update_product') }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            <input name="id" type="hidden" class="form-control" id="id"
                                value="{{ $edits['id'] }}">
                            <div class="form-group mb-4">
                                <label class="control-label">Title</label>
                                <input type="text" name="title" class="form-control" value="{{ $edits['title'] }}">
                            </div>


                            <div class="">
                                <div class="d-flex justify-content-between px-3 py-3">
                                    <div class="">
                                        <h4 class="">Pricing & Dimensions</h4>
                                    </div>
                                    <div class="">
                                        <button type="button" class="btn btn-success add-more">Add More</button>
                                    </div>
                                </div>
                            </div>
                            <div class="row dynamicFieldCon">

                                @if (isset($edits->dimension) && !empty($edits->dimension))
                                @php
                                    $i = 0;    
                                @endphp
                                    @foreach ($edits->dimension as $dimension)
                                    <input type="hidden" name="dimensions[dimension_id][]" value="{{ $dimension->id }}">
                                        <div class="col-lg-12 mb-4">
                                            <div class="shadow px-4 py-3">
                                                <div class="row">
                                                    @if( $i != 0)
                                                    <div class="col-lg-12 text-right">
                                                        <button type="button" class="btn btn-danger delete-dimension "
                                                            data-dimension-id="{{ $dimension->id }}"><i
                                                                class="fa fa-trash"></i></button>
            
                                                    </div>
                                                    @endif
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label for="selling_price">Selling Price ($)</label>
                                                            <input type="number" class="form-control" id="selling_price"
                                                                name="dimensions[selling_price][]" required
                                                                placeholder="Enter Selling Price"
                                                                value="{{ $dimension->selling_price }}" min="0">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label for="offer_price">Offer Price ($)</label>
                                                            <input type="number" class="form-control" id="offer_price"
                                                                name="dimensions[offer_price][]" required
                                                                placeholder="Enter Offer Price"
                                                                value="{{ $dimension->offer_price }}" min="0">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label for="shipping_charge">Shipping & Packaging Charges
                                                                ($)</label>
                                                            <input type="number" class="form-control" id="shipping_charge"
                                                                name="dimensions[shipping_charge][]" required
                                                                placeholder="Enter Shipping & Packaging Charges"
                                                                value="{{ $dimension->shipping_charge }}" min="0">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label for="dimensions">Dimensions</label>
                                                            <input type="text" class="form-control" id="dimensions"
                                                                name="dimensions[dimensions][]" required
                                                                placeholder="Enter dimensions"
                                                                value="{{ $dimension->dimensions }}">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        @php
                                        $i++;
                                    @endphp
                                    @endforeach
                                @endif


                            </div>


                            <div class="form-group mb-4 d-none">
                                <label class="control-label">Slug</label>
                                <input type="text" name="slug" class="form-control" value="{{ $edits['slug'] }}">
                            </div>

                            <div class="n-chk form-group">
                                <label class="new-control new-checkbox checkbox-success">
                                    <input type="checkbox" class="new-control-input" name="status" value="1"
                                        @if ($edits->status == 1) {{ 'checked' }} @endif>
                                    <span class="new-control-indicator"></span>Publish
                                </label>
                            </div>

                            <div class="row">

                                <div class="col-lg-4">


                                    <div class="form-group mb-4">
                                        <label class="control-label">Categories</label>
                                        <div class="select2-purple">
                                            <select class="select2" multiple="multiple" name="categories[]"
                                                ata-dropdown-css-class="select2-purple" style="width: 100%;">
                                                @foreach ($categories as $category)
                                                    <option value="{{ $category->id }}"
                                                        @foreach ($edits->categories as $postCategory)
                                    @if ($postCategory->id == $category->id)
                                    selected
                                    @endif @endforeach>
                                                        {{ $category->title }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label class="control-label">Literature</label>
                                        <select class="form-control" style="width: 100%;" name="literature_id" required>
                                            <option value="">Select Literature...</option>
                                            @foreach ($literatures as $literature)
                                                <option value="{{ $literature->id }}"
                                                    {{ $edits->literature_id == $literature->id ? 'selected' : '' }}>
                                                    {{ $literature->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label class="control-label" for="order_number">Order Number</label>
                                        <input name="order_number" type="number" class="form-control" id="order_number"
                                            value="{{ $edits->order_number }}">
                                        <small id="orderError" class="text-danger"></small>
                                    </div>
                                </div>


                            </div>
                            {{-- <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="control-label">Dimensions</label>
                                    <textarea name="dimensions" id="summernote2" cols="0" class="w-100" rows="5">{{ $edits->dimensions }}</textarea>
                                </div>
                            </div> --}}



                            <div class="form-group mb-4">
                                <label class="control-label">Content</label>
                                <textarea id="summernote" name="body" height="40">{{ $edits['body'] }}</textarea>
                            </div>

                            <div class="card card-default p-3">
                                <div class="card-header">
                                    <h3 class="card-title">Product Image</h3>
                                </div>

                                <div class="row mx-3">
                                    @foreach ($edits->featuredimage as $image)
                                        <div class="col-lg-2 my-2 mx-0 px-0">

                                            <img src="{{ $image['path'] }}" alt="Featured Image" class="w-100"
                                                height="230">
                                            <div class="img-container"> <span
                                                    class="position-absoulate delete-image d-flex delete_frame_image justify-content-center"
                                                    data-id="{{ $edits['id'] }}" data-name="{{ $image['name'] }}"><i
                                                        class="fa fa-trash py-1"></i></span>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>

                                <div class="custom-file-container my-4" data-upload-id="myImages">
                                    <label for="" class="pb-0 mb-0">Product Frame Images</label>
                                    <div class="input-group card-body pb-1 pt-2 px-0">
                                        <input type="file" class="form-control" accept="image/*"
                                            name="featuredimages[]" multiple>
                                    </div>
                                    <small class="text-primary my-2">(Select Only Two Images By Holding Down the 'Ctrl'
                                        Button.)</small>
                                </div>





                                <div class="row">
                                    @foreach ($edits->other_images as $image)
                                        <div class="col-lg-2 my-2">

                                            <img src="{{ $image['path'] }}" alt="Featured Image" width="200"
                                                height="160">
                                            <div class="img-container"> <span
                                                    class="position-absoulate delete-image d-flex justify-content-center delete_other_image"
                                                    data-id="{{ $edits['id'] }}" data-name="{{ $image['name'] }}"><i
                                                        class="fa fa-trash py-1"></i></span>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>

                                <div class="custom-file-container my-4" data-upload-id="myImages">
                                    <label for="" class="pb-0 mb-0">Product Other Images</label>
                                    <div class="input-group card-body pb-1 pt-2 px-0">
                                        <input type="file" class="form-control" accept="image/*"
                                            name="other_images[]" multiple>
                                    </div>
                                    <small class="text-primary my-2">(Select Multiple Images By Holding Down the 'Ctrl'
                                        Button.)</small>
                                </div>



                            </div>

                            <div class="card-footer">
                                <input type="submit" value="Submit" class="btn btn-primary ml-3 mt-3">

                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>
        </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.delete-dimension').click(function() {
                var dimensionId = $(this).data('dimension-id');
                $.ajax({
                    url: '{{ route('admin.dimension.delete', ['dimensionId' => ':dimensionId']) }}'
                        .replace(':dimensionId', dimensionId),
                    type: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        // Remove the parent dimension section if deletion is successful
                        if (response.success) {
                            $(this).closest('.mb-4').remove();
                        }
                    }.bind(this),
                    error: function(xhr, status, error) {
                        console.error(error);
                    }
                });
           
            });


            $(document).on('click', '.btn_remove', function(){  
            var button_id = $(this).attr("id");  
            $('#row'+button_id+'').remove();  
            $(this).remove()
            });
	


            var i = 1;
            $(".add-more").click(function() {
                i++;
                var newSection = `
            <div class="col-lg-12 mb-4 d_con" id="row${i}">
                <div class="shadow px-4 py-3">
                    <div class="row">
                        <div class="col-lg-12 text-right">
                                <button type="button" id="${i}"  class="btn btn-danger btn_remove delete-dimension"><i class="fa fa-trash"></i></button>
                            </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="selling_price">Selling Price ($)</label>
                                <input type="number" class="form-control" name="dimensions[selling_price][]" required placeholder="Enter Selling Price" min="0">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="offer_price">Offer Price ($)</label>
                                <input type="number" class="form-control" name="dimensions[offer_price][]" min="0" required placeholder="Enter Offer Price">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="shipping_charge">Shipping & Packaging Charges ($)</label>
                                <input type="number" class="form-control" name="dimensions[shipping_charge][]" required min="0" placeholder="Enter Shipping & Packaging Charges">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="dimensions">Dimensions</label>
                                <input type="text" class="form-control" name="dimensions[dimensions][]" required placeholder="Enter dimensions">
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
                $(".dynamicFieldCon").append(newSection);
            });
        });
    </script>
@endsection
