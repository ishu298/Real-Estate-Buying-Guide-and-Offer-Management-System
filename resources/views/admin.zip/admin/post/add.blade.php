@extends('layouts.master')
@section('content')
    <style>
        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type="number"] {
            -moz-appearance: textfield;
            /* Firefox */
        }
    </style>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Art Product Form</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Art Product Form</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-xl-12 col-lg-12 col-sm-12">
                    <!-- general form elements -->
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title">Add Art Product</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form action="{{ route('admin.store_product') }}" method="POST" enctype="multipart/form-data"
                            class="dropzone" id="my-awesome-dropzone">
                            @csrf
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="postTitleInput">Title</label>
                                    <input type="text" class="form-control" id="postTitleInput" name="title" required
                                        placeholder="Enter title here">
                                </div>



                                <div class="form-group d-none">
                                    <label for="postSlugInput">Slug</label>
                                    <input type="text" class="form-control " id="postSlugInput" name="slug" required
                                        placeholder="Example: this-is-demo-slug">
                                </div>

                                <div class="row">

                                    <div class="col-lg-12 mb-4">
                                        <div class="shadow  px-4 py-3">
                                            <div class="d-flex justify-content-between">
                                                <div class="">
                                                    <h4 class="pb-3">Pricing & Dimensions</h4>
                                                </div>
                                                <div class="">
                                                    <button type="button" class="btn btn-success add-more">Add More</button>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="selling_price">Selling Price ($)</label>
                                                        <input type="number" class="form-control" id="selling_price"
                                                        name="dimensions[selling_price][]" required placeholder="Enter Selling Price"
                                                            min="0">
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="offer_price">Offer Price ($)</label>
                                                        <input type="number" class="form-control" id="offer_price"
                                                        name="dimensions[offer_price][]" min="0" required
                                                            placeholder="Enter Offer Price">
                                                    </div>
                                                </div>

                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="shipping_charge">Shipping & Packaging Charges
                                                            ($)</label>
                                                        <input type="number" class="form-control" id="shipping_charge"
                                                        name="dimensions[shipping_charge][]" required min="0"
                                                            placeholder="Enter Shipping & Packaging Charges">
                                                    </div>
                                                </div>

                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="dimensions">Dimensions</label>
                                                        <input type="text" class="form-control" id="dimensions"
                                                        name="dimensions[dimensions][]" required min="0"
                                                            placeholder="Enter dimensions">
                                                    </div>
                                                </div>


                                            </div>


                                        </div>
                                    </div>



                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label">Categories</label>
                                            <div class="select2-purple">
                                                <select class="select2" multiple="multiple"
                                                    data-dropdown-css-class="select2-purple" style="width: 100%;"
                                                    name="categories[]">
                                                    @foreach ($lists1 as $list)
                                                        <option value="{{ $list->id }}">{{ $list->title }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label">Literature</label>
                                            <select class="form-control" style="width: 100%;" name="literature_id" required>
                                                <option value="">Select Literature...</option>
                                                @foreach ($literatures as $literature)
                                                    <option value="{{ $literature->id }}">{{ $literature->title }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label" for="order_number">Order Number</label>
                                            <input name="order_number" type="number" class="form-control"
                                                id="order_number" placeholder="Enter Order Number">
                                            <small id="orderError" class="text-danger"></small>


                                        </div>
                                    </div>

                                    {{-- <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="control-label">Dimensions</label>
                                            <textarea name="dimensions" id="summernote2" cols="0" class="w-100" rows="5"></textarea>
                                        </div>
                                    </div> --}}



                                </div>


                                <div class="card card-outline card-info">
                                    <div class="card-header">
                                        <h3 class="card-title">
                                            Content
                                        </h3>
                                    </div>
                                    <!-- /.card-header -->
                                    <div class="card-body">
                                        <textarea id="summernote" name="body" cols="0" class="w-100" rows="5">
                                               
                                         </textarea>
                                    </div>
                                </div>





                                <div class="card card-default">
                                    <div class="card-header">
                                        <h3 class="card-title">Product Image</h3>
                                    </div>

                                    <div class="form-group pt-3">
                                        <label for="" class="pb-0 mb-0 mx-4">Product Frame Images</label>
                                        <div class="input-group card-body pb-1 pt-2">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="exampleInputFile"
                                                    name="featuredimages[]" multiple>
                                                <label class="custom-file-label" for="exampleInputFile">Choose
                                                    file</label>

                                            </div>
                                            <div class="input-group-append">
                                                <span class="input-group-text">Upload</span>
                                            </div>
                                        </div>
                                        <small class="mx-4 text-primary">(Select Only Two Images By Holding Down the 'Ctrl'
                                            Button.)</small>
                                    </div>



                                    <div class="form-group">
                                        <label for="" class="pb-0 mb-0 mx-4 ">Product Other Images</label>
                                        <div class="input-group card-body pb-1 pt-2">

                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="exampleInputFile"
                                                    name="other_images[]" multiple>
                                                <label class="custom-file-label" for="exampleInputFile">Choose
                                                    file</label>

                                            </div>
                                            <div class="input-group-append">
                                                <span class="input-group-text">Upload</span>
                                            </div>
                                        </div>
                                        <small class="mx-4 text-primary">(Select Multiple Images By Holding Down the 'Ctrl'
                                            Button.)</small>
                                    </div>

                                </div>

                                <div class="n-chk form-group">
                                    <label class="new-control new-checkbox checkbox-success">
                                        <input type="checkbox" checked class="new-control-input" name="status"
                                            value="1">
                                        <span class="new-control-indicator"></span>Publish
                                    </label>
                                </div>


                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $('#postTitleInput').keyup(function() {
            var replaceSpace = $(this).val();
            var result = replaceSpace.replace(/\s/g, "-").toLowerCase();
            $("#postSlugInput").val(result);
        });

        $(document).on('click', '.btn_remove', function(){  
            var button_id = $(this).attr("id");  
            $('#row'+button_id+'').remove();  
            $(this).remove()
            });

        $(document).ready(function(){
            var i = 1;
            $(".add-more").click(function() {
                i++;
        var newSection = `
            <div class="col-lg-12 mb-4" id="row${i}">
                <div class="shadow px-4 py-3">
                    <div class="row">
                        <div class="col-lg-12 text-right">
                                <button type="button" id="${i}"  class="btn btn-danger btn_remove delete-dimension"><i class="fa fa-trash"></i></button>
                            </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="selling_price">Selling Price ($)</label>
                                <input type="number" class="form-control" name="dimensions[selling_price][]" required placeholder="Enter Selling Price" min="0">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="offer_price">Offer Price ($)</label>
                                <input type="number" class="form-control" name="dimensions[offer_price][]" min="0" required placeholder="Enter Offer Price">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="shipping_charge">Shipping & Packaging Charges ($)</label>
                                <input type="number" class="form-control" name="dimensions[shipping_charge][]" required min="0" placeholder="Enter Shipping & Packaging Charges">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="dimensions">Dimensions</label>
                                <input type="text" class="form-control" name="dimensions[dimensions][]" required placeholder="Enter dimensions">
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
        $(".add-more").closest(".col-lg-12").after(newSection);
    });
});



    </script>
@endsection
