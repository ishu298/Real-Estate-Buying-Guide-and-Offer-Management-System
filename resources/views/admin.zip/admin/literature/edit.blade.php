@extends('layouts.master')
@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Literature Form</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Edit Literature Form</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-xl-12 col-lg-12 col-sm-12">
                    <!-- general form elements -->
                    <div class="card card-success">
                        <div class="card-header">
                            <h3 class="card-title">Edit Literature</h3>
                        </div>
                        <form class="dropzone p-4" id="my-awesome-dropzone" action="{{ route('admin.update_literature') }}"
                            method="POST" enctype="multipart/form-data">
                            @csrf
                            <input name="id" type="hidden" class="form-control" id="id"
                                value="{{ $edits['id'] }}">
                            <div class="form-group mb-4">
                                <label class="control-label">Title</label>
                                <input type="text" name="title" class="form-control" value="{{ $edits['title'] }}">
                            </div>
                            <div class="form-group mb-4">
                                <label class="control-label">Slug</label>
                                <input type="text" name="slug" class="form-control" value="{{ $edits['slug'] }}">
                            </div>

                            <div class="n-chk form-group mb-4">
                                <label class="new-control new-checkbox checkbox-success">
                                    <input type="checkbox" class="new-control-input" name="status" value="1"
                                        @if ($edits->status == 1) {{ 'checked' }} @endif>
                                    <span class="new-control-indicator"></span>Publish
                                </label>
                            </div>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group mb-4">
                                        <label class="control-label">Categories</label>
                                        <div class="select2-purple">
                                            <select class="select2" multiple="multiple" name="categories[]"
                                                ata-dropdown-css-class="select2-purple" style="width: 100%;">
                                                @foreach ($categories as $category)
                                                    <option value="{{ $category->id }}"
                                                        @foreach ($edits->literature_categories as $postCategory)
                                    @if ($postCategory->id == $category->id)
                                    selected
                                    @endif @endforeach>
                                                        {{ $category->title }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label" for="literature_order_number">Order Number</label>
                                        <input name="order_number" type="number" class="form-control" id="literature_order_number"
                                            value="{{ $edits->order_number }}">
                                        <small id="literatureOrderError" class="text-danger"></small>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group mb-4">
                                <label class="control-label">Content</label>
                                <textarea id="summernote" name="body">{{ $edits['body'] }}</textarea>
                            </div>

                            {{-- @if (isset($edits->featuredimage['path']))
                                <div class="row">
                                    <div class="col-lg-2 my-2">
                                        <img src="{{ $edits->featuredimage['path'] }}" alt="Featured Image" width="130"
                                            height="130">
                                    </div>
                                </div>
                            @endif --}}

                            <div class="row mx-3">
                                @foreach ($edits->featuredimage as $image)
                                    <div class="col-lg-2 mt-2 mb-5 mr-3 px-0">

                                        <img src="{{ $image['path'] }}" alt="Featured Image" class="w-100"
                                            height="230">
                                        <div class="img-container"> <span
                                                class="position-absoulate delete-image d-flex delete_literature_image justify-content-center btn btn-danger rounded-0"
                                                data-id="{{ $edits['id'] }}" data-name="{{ $image['name'] }}"><i class="fa fa-trash py-1"></i></span>
                                        </div>
                                    </div>
                                @endforeach
                            </div>


                            <div class="custom-file-container mb-3" data-upload-id="myImages">
                                {{-- <label>Upload (Multiple Files) <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Images">x</a></label> --}}
                                <label class="custom-file-container__custom-file">
                                    <input type="file" class="custom-file-container__custom-file__custom-file-input"
                                        accept="image/*" name="featuredimages[]" multiple>
                                    <span class="custom-file-container__custom-file__custom-file-control"></span>
                                </label>
                                <div class="custom-file-container__image-preview"></div>
                                <small class="text-primary my-2">(Select Multiple Images By Holding Down the 'Ctrl'
                                    Button.)</small>
                            </div>


                            <input type="submit" value="Submit" class="btn btn-primary ml-3 mt-3">
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $('.delete_literature_image').click(function() {
            var imageName = $(this).data('name');
            var imageId = $(this).data('id');

            $.ajax({
                url: "{{ route('admin.delete_literature_image', ['id' => ':id', 'name' => ':name']) }}".replace(':id', imageId).replace(':name', imageName),
                type: 'GET',
                success: function(response) {
                    console.log('response',response);
                    if(response == 1 ){               
                        window.location.reload();
                        console.log(response);
                    }
                },
                error: function(error) {
                    console.error(error);
                }
            });
        });

    </script>
@endsection
