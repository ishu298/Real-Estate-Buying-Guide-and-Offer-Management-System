@extends('layouts.master')
@section('content')
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <a href="{{ route('admin.add_literature') }}"><button type="button" class="btn btn-primary mb-2 m-3">
                    Add New Literature
                </button></a>

            <div class="card-body" >
                <table id="example5" class="table table-bordered table-striped sortable-table">
                    <thead>
                        <tr>
                            <th>id</th>
                          
                            <th>Title</th>
                            {{-- <th>Category</th> --}}
                            <th>Status</th>
                            <th>Order#</th>
                            <th>Image</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="sortable">
                        <?php $Sno = 1; ?>
                        @foreach ($lists as $list)
                        <tr id="{{ $list['id'] }}" class="sortable-row">
                                <td>{{ $Sno }}</td>
                           
                                <td>{{ $list['title'] }}</td>
                                @if ($list->status == '1')
                                    <td>Published</td>
                                @else
                                    <td>Not Published</td>
                                @endif
                                <td>{{$list['order_number']}}</td>
                                <td>

                                    @foreach($list->featuredimage as $images)
                                    {{-- @if (isset($list['featuredimage']['name']) && !empty($list['featuredimage'])) --}}
                                        <img src="{{ $images['path'] }}" alt="" srcset="" width="50" height="50">
                                    {{-- @else
                                        <p>-</p>        
                                    @endif --}}
                                    @endforeach
                                </td>


                                <td>{{ $list['updated_at'] }}</td>
                                <td>
                                    <a class="btn btn-success"
                                        href="{{ route('admin.edit_literature', ['id' => $list['id']]) }}">Edit</a>
                                    <a class="btn btn-danger"
                                        href="{{ route('admin.destroy_literature', ['id' => $list['id']]) }}"
                                        onclick="return confirm('Are you sure?');">Delete</a>
                                </td>
                            </tr>
                            <?php $Sno++; ?>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
   


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script>
        $(function() {
            $("#sortable").sortable({
                update: function(event, ui) {
                    var sortedData = $(this).sortable('toArray');
                    console.log('sortedData',sortedData);
                    $.ajax({
                        url: '{{ route("admin.orderUpdate") }}',
                        method: 'POST',
                        data: {
                            sorted_data: sortedData,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            // Handle success if needed
                            console.log(response);
                        },
                        error: function(xhr, status, error) {
                            // Handle error if needed
                            console.error(xhr.responseText);
                        }
                    });
                }
            });
            $("#sortable").disableSelection();
        });
    </script>

@endsection

